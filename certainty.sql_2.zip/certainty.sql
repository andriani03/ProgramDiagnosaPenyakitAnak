-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 21, 2012 at 05:20 AM
-- Server version: 5.1.33
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `certainty`
--

-- --------------------------------------------------------

--
-- Table structure for table `gejala`
--

CREATE TABLE IF NOT EXISTS `gejala` (
  `id_gejala` int(2) NOT NULL,
  `nama_gejala` varchar(25) NOT NULL,
  `CF` float NOT NULL,
  PRIMARY KEY (`id_gejala`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gejala`
--

INSERT INTO `gejala` (`id_gejala`, `nama_gejala`, `CF`) VALUES
(1, 'Demam', 0.7),
(2, 'Batuk', 0.3),
(3, 'Napas berbunyi', 0.6),
(4, 'Napas sangat cepat', 0.2),
(5, 'Napas megap-megap', 0.8);

-- --------------------------------------------------------

--
-- Table structure for table `pasien`
--

CREATE TABLE IF NOT EXISTS `pasien` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `nama` varchar(40) NOT NULL,
  `umur` int(3) NOT NULL,
  `kelamin` enum('P','W') NOT NULL,
  `alamat` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `pasien`
--

INSERT INTO `pasien` (`id`, `nama`, `umur`, `kelamin`, `alamat`) VALUES
(1, '1', 1, 'P', '1'),
(2, '2', 2, 'P', '2'),
(3, '3', 3, 'P', '3'),
(4, 'tes', 4, 'W', 'seke'),
(5, 'a', 9, 'P', 'tuis'),
(6, 'ane', 7, 'P', 'tui'),
(7, 'Renggs', 89, 'P', 'bandung'),
(8, 'tes lagi', 10, 'P', 'du'),
(9, 'tes2', 1, 'P', '11'),
(10, 'qwerty', 1, 'P', '1'),
(11, 'nm', 2, 'P', '2'),
(12, 'kl', 7, 'P', 'hj'),
(13, 'susi', 5, 'W', 'tuisba'),
(14, 'tes', 9, 'P', 'tuis atas');

-- --------------------------------------------------------

--
-- Table structure for table `penyakit`
--

CREATE TABLE IF NOT EXISTS `penyakit` (
  `id_penyakit` int(2) NOT NULL,
  `nama_penyakit` varchar(30) NOT NULL,
  `CF` float NOT NULL,
  PRIMARY KEY (`id_penyakit`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penyakit`
--

INSERT INTO `penyakit` (`id_penyakit`, `nama_penyakit`, `CF`) VALUES
(1, 'Infeksi saluran napas', 0.52),
(2, 'Infeksi dada', 0.45),
(3, 'Influenza', 0.74);

-- --------------------------------------------------------

--
-- Table structure for table `relasi`
--

CREATE TABLE IF NOT EXISTS `relasi` (
  `id_gejala` int(2) NOT NULL,
  `id_penyakit` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `relasi`
--

INSERT INTO `relasi` (`id_gejala`, `id_penyakit`) VALUES
(1, 1),
(2, 1),
(3, 1),
(1, 2),
(2, 2),
(4, 2),
(1, 3),
(2, 3),
(5, 3);

-- --------------------------------------------------------

--
-- Table structure for table `temp`
--

CREATE TABLE IF NOT EXISTS `temp` (
  `id_gejala` int(2) NOT NULL,
  `status` varchar(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `temp`
--

INSERT INTO `temp` (`id_gejala`, `status`) VALUES
(1, 'Iya'),
(2, 'Iya'),
(3, 'Iya'),
(4, 'Iya');
